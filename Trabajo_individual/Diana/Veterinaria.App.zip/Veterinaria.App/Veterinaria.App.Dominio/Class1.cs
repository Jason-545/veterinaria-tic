﻿using System;

namespace Veterinaria.App.Dominio
{
    public class Class1
    {
    }
}
