using System;

namespace Veterinaria.App.Dominio
{

    public class EntidadMascota{
        public int Id {get; set;}
        public String Nombre {get; set;}
        public int Edad {get; set;}
        public float Peso {get; set;}
        public String Especie {get; set;}
    }
    
}