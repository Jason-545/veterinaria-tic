﻿using System;

namespace Veterinaria.App.Persistencia
{
    public class Class1
    {
    }
}
